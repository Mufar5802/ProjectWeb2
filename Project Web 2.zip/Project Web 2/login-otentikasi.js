function login() {
    let username = document.getElementById('username');
    let password = document.getElementById('password');

    if (username.value === 'admin') {
        window.location.href = 'Hal1.html';
    } 
    else {
        window.alert('Gagal Login. Silahkan Coba Lagi')
    }
}